<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ej8</title>
</head>
<body>
    <h1>Ejercicio 8</h1>
    <form action="ej8.php" method="post">
        <label for="n1">Ingrese un número: </label>
        <input type="number" name="n1" id="n1">
        <button type="submit">Enviar</button>
    </form>
</body>
</html>