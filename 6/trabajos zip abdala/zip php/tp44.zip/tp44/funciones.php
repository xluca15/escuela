<?php
    function invertir($palabra){
        $palabra = strrev($palabra);
        return $palabra;
    }
?>