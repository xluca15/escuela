<?php
    $p1 = $_POST ['p1'];
    include_once ('funciones.php');
    echo 'la plabra al reves es ' .  invertir($p1);
?>