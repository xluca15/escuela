<?php
    function cambiarPalabra($p1, $n1){
       $p1[$n1-1] = "X";
        return $p1;
    }
?>