<?php
    include_once 'funcion.php';
    echo cambiarPalabra($_POST['p1'], $_POST['n1']);
?>