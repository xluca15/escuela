<?php
    $n = $_POST["n1"];
    for ($i = 0; $i < $n; $i++) {
        echo "Módulo ejecutándose <br/>";
    }
?>