<?php  
function mayor ($a,$b){ 
    if($a>$b){ 
        return $a; 
    } 
    else{ 
        return $b; 
    } 
} 
function menor ($a,$b){ 
    if($a<$b){ 
        return $a; 
    } 
    else{ 
        return $b; 
    } 
} 