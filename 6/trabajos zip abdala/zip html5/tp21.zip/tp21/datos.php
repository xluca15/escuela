<?php
    $p = $_POST ["num1"];
    echo ("el peso en la tierra es:" . $p ."<br>");
	function calculate($weight){
			$res = ($weight/9.81) * 1.622;
			return $res;
	}
?>