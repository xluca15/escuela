<?php
$n1=$_POST["n1"];
for ($i=0; $i < $n1; $i++) { 
    # code...
} 
?>